#pragma once

void prepareTestData();
